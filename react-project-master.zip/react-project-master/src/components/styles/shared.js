import styled from 'styled-components';

export const SharedStyle = styled.section`
  width: 90%;
  margin: 80px auto 0 auto;
`;
